document.addEventListener('DOMContentLoaded', () => {
  //   console.log(124);

  const modalElem = document.querySelector('.modal'),
    moreElems = document.querySelectorAll('.more');

  const openModal = () => {
    // console.log('open');
    modalElem.classList.remove('hidden');
    document.body.style.overflowY = 'hidden';
    document.body.style.marginLeft = '-17px';
  };

  const closeModal = (e) => {
    // console.log('close');
    modalElem.classList.add('hidden');
    document.body.style.overflowY = '';
    document.body.style.marginLeft = '';
  };

  moreElems.forEach((btn) => btn.addEventListener('click', openModal));
  modalElem.addEventListener('click', (e) => {
    if (e.target.classList.contains('overlay') || e.target.classList.contains('modal__close')) {
      closeModal();
    }
  });
});
