document.addEventListener('DOMContentLoaded', () => {
  const menuElem = document.querySelector('.menu'),
    burgerElem = document.querySelector('.humburger-menu');

  const closeMenu = () => {
    menuElem.classList.remove('menu-active');
    burgerElem.classList.remove('humburger-menu-active');
  };

  const toggleMenu = () => {
    menuElem.classList.toggle('menu-active');
    burgerElem.classList.toggle('humburger-menu-active');
  };

  burgerElem.addEventListener('click', toggleMenu);
  menuElem.addEventListener('click', (e) => {
    if (e.target.classList.contains('menu-list__link')) {
      closeMenu();
    }
  });
});
