document.addEventListener('DOMContentLoaded', () => {
  //   console.log(122);
  const links = document.querySelectorAll('a[href^="#"]:not(a[href="#"])');
  links.forEach((link) => {
    //console.log(link.href);
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const id = link.getAttribute('href').substring(1);
      //   console.log(id);
      document.getElementById(id).scrollIntoView({
        behavior: 'smooth',
      });
    });
  });
});
