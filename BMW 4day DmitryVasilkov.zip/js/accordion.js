document.addEventListener('DOMContentLoaded', () => {
  //   console.log(121);
  const featureLinksElems = document.querySelectorAll('.feature__link'),
    featureSubElems = document.querySelectorAll('.feature-sub');
  //a
  /*
  featureLinksElems.forEach((el, index)=>{
        el.addEventListener('click',()=>{
            featureSubElems[index].classList.toggle('hidden');
            el.classList.toggle('feature__link_active');
        });
    });
*/
  //b
  /*
  featureLinksElems.forEach((el, index) => {
    el.addEventListener('click', () => {
      if (el.classList.contains('feature__link_active')) {
        el.classList.remove('feature__link_active');
        featureSubElems[index].classList.add('hidden');
      } else {
        featureSubElems.forEach((sub) => sub.classList.add('hidden'));
        featureLinksElems.forEach((link) => link.classList.remove('feature__link_active'));
        el.classList.add('feature__link_active');
        featureSubElems[index].classList.remove('hidden');
      }
    });
  });
  */

  //c
  featureLinksElems.forEach((el, index) => {
    el.addEventListener('click', () => {
      featureSubElems.forEach((sub, i) => {
        if (index === i) {
          featureSubElems[index].classList.toggle('hidden');
        } else {
          sub.classList.add('hidden');
        }
      });

      featureLinksElems.forEach((link) => {
        if (link === el) {
          el.classList.toggle('feature__link_active');
        } else {
          link.classList.remove('feature__link_active');
        }
      });
    });
  });
});
