document.addEventListener('DOMContentLoaded', () => {
  // console.log(123);
  const tabsHandlerElems = document.querySelectorAll('[data-tabs-handler]'),
    tabsFieldElems = document.querySelectorAll('[data-tabs-field]');

  for (const tab of tabsHandlerElems) {
    tab.addEventListener('click', () => {
      tabsHandlerElems.forEach((item) => {
        if (tab === item) {
          item.classList.add('design-list__item_active');
        } else {
          item.classList.remove('design-list__item_active');
        }
      });
      tabsFieldElems.forEach((item) => {
        if (tab.dataset.tabsHandler === item.dataset.tabsField) {
          item.classList.remove('hidden');
        } else {
          item.classList.add('hidden');
        }
      });
    });
  }
});
